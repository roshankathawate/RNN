from __future__ import division
import numpy as np

def eval_numerical_gradient_array(f, x, df, h=1e-5):
    """
    Evaluate a numeric gradient for a function that accepts a numpy
    array and returns a numpy array.
    """
    grad = np.zeros_like(x)
    it = np.nditer(x, flags=['multi_index'], op_flags=['readwrite'])
    while not it.finished:
        ix = it.multi_index

        oldval = x[ix]
        x[ix] = oldval + h
        pos = f(x).copy()
        x[ix] = oldval - h
        neg = f(x).copy()
        x[ix] = oldval

        grad[ix] = np.sum((pos - neg) * df) / (2 * h)
        it.iternext()
    return grad

def lstm_step_forward(x, prev_h, prev_c, Wx, Wh, b):
    """
    Forward pass for a single timestep of an LSTM.
    The input data has dimension D, the hidden state has dimension H, and we use
    a minibatch size of N.
    Inputs:
    - x: Input data, of shape (N, D)
    - prev_h: Previous hidden state, of shape (N, H)
    - prev_c: previous cell state, of shape (N, H)
    - Wx: Input-to-hidden weights, of shape (D, 4H)
    - Wh: Hidden-to-hidden weights, of shape (H, 4H)
    - b: Biases, of shape (4H,)
    Returns a tuple of:
    - next_h: Next hidden state, of shape (N, H)
    - next_c: Next cell state, of shape (N, H)
    - cache: Tuple of values needed for backward pass.
    """
    next_h, next_c, cache = None, None, None
    _, H = prev_c.shape

    a = np.dot(x, Wx) + np.dot(prev_h, Wh) + b #(N, 4H)
    #divide into 4 vectors ai, af, ao, ag
    ai = a[:, :H]
    af = a[:, H:2*H]
    ao = a[:, 2*H:3*H]
    ag = a[:, 3*H:4*H]
    # print "ai: ", ai.shape

    #input gate
    i = sigmoid(ai)
    #forget gate
    f = sigmoid(af)
    #output gate
    o = sigmoid(ao)
    #control gate
    g = np.tanh(ag)

    #next cell state
    next_c = f * prev_c + i * g
    #next hidden state
    next_h = o * np.tanh(next_c)
    cache = (x, prev_h, prev_c, Wx, Wh, b, i, f, o, g, next_c)

    return next_h, next_c, cache

def lstm_step_backward(dnext_h, dnext_c, cache):
    """
    Backward pass for a single timestep of an LSTM.
    Inputs:
    - dnext_h: Gradients of next hidden state, of shape (N, H)
    - dnext_c: Gradients of next cell state, of shape (N, H)
    - cache: Values from the forward pass
    Returns a tuple of:
    - dx: Gradient of input data, of shape (N, D)
    - dprev_h: Gradient of previous hidden state, of shape (N, H)
    - dprev_c: Gradient of previous cell state, of shape (N, H)
    - dWx: Gradient of input-to-hidden weights, of shape (D, 4H)
    - dWh: Gradient of hidden-to-hidden weights, of shape (H, 4H)
    - db: Gradient of biases, of shape (4H,)
    """
    dx, dh, dc, dWx, dWh, db = None, None, None, None, None, None
    dprev_h = None
    x, prev_h, prev_c, Wx, Wh, b, i, f, o, g, next_c = cache
    tanh_nextc = np.tanh(next_c)
    dprev_c = (dnext_c * f) + ((o * (1- np.power(tanh_nextc, 2)) * f) * dnext_h)
    di = (dnext_c * g) + ((o * (1- np.power(tanh_nextc, 2)) * g) * dnext_h)
    df = (dnext_c * prev_c) + ((o * (1- np.power(tanh_nextc, 2)) * prev_c) * dnext_h)
    dg = (dnext_c * i) + ((o * (1- np.power(tanh_nextc, 2)) * i) * dnext_h)
    do = dnext_h * tanh_nextc
    
    di = (di * i) * (1 - i)
    df = (df * f) * (1 - f)
    do = (do * o) * (1 - o)
    dg = dg * (1 - np.power(g, 2))

    di_forgate = np.hstack((di, df, do, dg))

    dWh = np.dot(prev_h.T, di_forgate)
    dWx = np.dot(x.T, di_forgate)
    db = di_forgate.sum(axis=0)

    dx = np.dot(di_forgate, Wx.T)
    dprev_h = np.dot(di_forgate, Wh.T)
    dx = np.dot(di_forgate, Wx.T)
    dprev_h = np.dot(di_forgate, Wh.T)
    return dx, dprev_h, dprev_c, dWx, dWh, db

def lstm_forward(x, h0, Wx, Wh, b):
    """
    Forward pass for an LSTM over an entire sequence of data. We assume an input
    sequence composed of T vectors, each of dimension D. The LSTM uses a hidden
    size of H, and we work over a minibatch containing N sequences. After running
    the LSTM forward, we return the hidden states for all timesteps.
    Note that the initial cell state is passed as input, but the initial cell
    state is set to zero. Also note that the cell state is not returned; it is
    an internal variable to the LSTM and is not accessed from outside.
    Inputs:
    - x: Input data of shape (N, T, D)
    - h0: Initial hidden state of shape (N, H)
    - Wx: Weights for input-to-hidden connections, of shape (D, 4H)
    - Wh: Weights for hidden-to-hidden connections, of shape (H, 4H)
    - b: Biases of shape (4H,)
    Returns a tuple of:
    - h: Hidden states for all timesteps of all sequences, of shape (N, T, H)
    - cache: Values needed for the backward pass.
    """
    h, cache = None, None
    _, H = h0.shape
    N, T, D = x.shape
    h = np.zeros((N, T, H))
    prev_h = h0
    prev_c = np.zeros(h0.shape)
    cache = []
    for i in range(T):
        h_t, c_t, cache_t = lstm_step_forward(x[:, i, :], prev_h, prev_c, Wx, Wh, b)
        prev_h = h_t
        prev_c = c_t
        h[:, i, :] = h_t
        cache.append(cache_t)
    
    return h, cache

def lstm_backward(dh, cache):
    """
    Backward pass for an LSTM over an entire sequence of data.]
    Inputs:
    - dh: Upstream gradients of hidden states, of shape (N, T, H)
    - cache: Values from the forward pass
    Returns a tuple of:
    - dx: Gradient of input data of shape (N, T, D)
    - dh0: Gradient of initial hidden state of shape (N, H)
    - dWx: Gradient of input-to-hidden weight matrix of shape (D, 4H)
    - dWh: Gradient of hidden-to-hidden weight matrix of shape (H, 4H)
    - db: Gradient of biases, of shape (4H,)
    """
    dx, dh0, dWx, dWh, db = None, None, None, None, None
    N, T, H = dh.shape
    D = cache[0][0].shape[1]
    dx = np.zeros((N, T, D))
    dh0 = np.zeros((N, H))
    dWx = np.zeros((D, 4 * H))
    dWh = np.zeros((H, 4 * H))
    db = np.zeros((4 * H))
    dprev_h_t = np.zeros((N, H))
    dprev_c_t = np.zeros((N, H))
    for i in range(T - 1, -1, -1):
        dxt, dprev_h_t,dprev_c_t, dWxt, dWht, dbt = lstm_step_backward(dh[:,i,:]+dprev_h_t,dprev_c_t, cache[i])
        dx[:, i, :] = dxt
        dWx += dWxt
        dWh += dWht
        db += dbt
    dh0 = dprev_h_t
    
    return dx, dh0, dWx, dWh, db



def sigmoid(x):
    return 1/(1 + np.exp(-x))

def rel_error(x, y):
    """ returns relative error """
    return np.max(np.abs(x - y) / (np.maximum(1e-8, np.abs(x) + np.abs(y))))



N, D, T, H = 2, 3, 10, 6

x = np.random.randn(N, T, D)
h0 = np.random.randn(N, H)
Wx = np.random.randn(D, 4 * H)
Wh = np.random.randn(H, 4 * H)
b = np.random.randn(4 * H)

out, cache = lstm_forward(x, h0, Wx, Wh, b)

dout = np.random.randn(*out.shape)

dx, dh0, dWx, dWh, db = lstm_backward(dout, cache)

fx = lambda x: lstm_forward(x, h0, Wx, Wh, b)[0]
fh0 = lambda h0: lstm_forward(x, h0, Wx, Wh, b)[0]
fWx = lambda Wx: lstm_forward(x, h0, Wx, Wh, b)[0]
fWh = lambda Wh: lstm_forward(x, h0, Wx, Wh, b)[0]
fb = lambda b: lstm_forward(x, h0, Wx, Wh, b)[0]

dx_num = eval_numerical_gradient_array(fx, x, dout)
dh0_num = eval_numerical_gradient_array(fh0, h0, dout)
dWx_num = eval_numerical_gradient_array(fWx, Wx, dout)
dWh_num = eval_numerical_gradient_array(fWh, Wh, dout)
db_num = eval_numerical_gradient_array(fb, b, dout)

print 'dx error: ', rel_error(dx_num, dx)
print 'dh0 error: ', rel_error(dx_num, dx)
print 'dWx error: ', rel_error(dx_num, dx)
print 'dWh error: ', rel_error(dx_num, dx)
print 'db error: ', rel_error(dx_num, dx)