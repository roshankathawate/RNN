def train(data):
    """
    Run optimization to train the model.
    """
    
    num_train = data['train_captions'].shape[0]
    iterations_per_epoch = max(num_train / batch_size, 1)
    num_iterations = num_epochs * iterations_per_epoch

    for t in xrange(num_iterations):
    	
		minibatch = sample_coco_minibatch(self.data, batch_size=self.batch_size, split='train')
		captions, features, urls = minibatch

		# Compute loss and gradient
		loss, grads = self.model.loss(features, captions)
		self.loss_history.append(loss)

		# Perform a parameter update
		for p, w in self.model.params.iteritems():
			dw = grads[p]
			config = self.optim_configs[p]
			next_w, next_config = self.update_rule(w, dw, config)
			self.model.params[p] = next_w
			self.optim_configs[p] = next_config


      # Maybe print training loss
      if self.verbose and t % self.print_every == 0:
        print '(Iteration %d / %d) loss: %f' % (
               t + 1, num_iterations, self.loss_history[-1])

      # At the end of every epoch, increment the epoch counter and decay the
      # learning rate.
      epoch_end = (t + 1) % iterations_per_epoch == 0
      if epoch_end:
        self.epoch += 1
        for k in self.optim_configs:
          self.optim_configs[k]['learning_rate'] *= self.lr_decay

      # Check train and val accuracy on the first iteration, the last
      # iteration, and at the end of each epoch.
      # TODO: Implement some logic to check Bleu on validation set periodically

    # At the end of training swap the best params into the model
# self.model.params = self.best_params


def load_data():
	batch_size = 3
	data = load_coco_data(pca_features=True)
	captions, features, urls = sample_coco_minibatch(data, batch_size=batch_size)
	print captions[:,:-1].shape
	print captions[:,1:].shape